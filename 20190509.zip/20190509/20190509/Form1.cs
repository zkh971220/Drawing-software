﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Reflection;

namespace _20190509
{
    public partial class Form1 : Form
    {
        Pen pen, pen0, pen6;//定义绘图、橡皮擦、选框的画笔
        Brush brush;//定义填充时的画刷
        bool mark = false;//判断鼠标是否按下
        Point Start, End;//定义画线的起点和终点
        Graphics G, bitG;//创建Graphics对象
        Bitmap bit;//用Bitmap类，窗口最小化图案才不会消失
        Rectangle rec3, rec4, rec6, rec7;//定义矩形对象
        Point point;//定义坐标点
        int type = 1;//定义绘图功能
        bool mark1 = false;//定义拖动窗口是否可移动
        int x = 0, y = 0;//定义拖动窗口的坐标
        String filename = "";//定义字符串保存文件路径
        [DllImport("user32.dll")]//调用dll文件，自定义鼠标指针需要用到
        public static extern IntPtr LoadCursorFromFile(string fileName);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pen = new Pen(Color.SkyBlue, 5);//设置画笔属性
            brush = new SolidBrush(Color.SlateBlue);//设置画刷属性
            bit = new Bitmap(pictureBox1.Width, pictureBox1.Height);//定义相纸大小
            bitG = Graphics.FromImage(bit);
            bitG.Clear(Color.White);//设置白色背景
            pictureBox1.Image = bit;//把相纸放入相框
            G = pictureBox1.CreateGraphics();//设置在哪画
            toolStripStatusLabel2.Text = "";

        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)//鼠标按下事件
        {
            if (e.Button == MouseButtons.Left)
            {
                mark = true;//判断鼠标是否按下
                Start = new Point(e.X, e.Y);
                End = new Point(e.X, e.Y);//定义画线的起点和终点
                point.X = e.X;
                point.Y = e.Y;
                
                if (radioButton1.Checked == true)//判断是否设置了画笔样式，并应用
                {
                    pen.DashStyle = DashStyle.Solid;
                }
                if (radioButton2.Checked == true)
                {
                    pen.DashStyle = DashStyle.Dash;
                }
                if (radioButton3.Checked == true)
                {
                    pen.DashStyle = DashStyle.DashDot;
                }
                if (radioButton4.Checked == true)
                {
                    pen.EndCap = LineCap.NoAnchor;
                }
                if (radioButton5.Checked == true)
                {
                    pen.EndCap = LineCap.ArrowAnchor;
                }
                if (radioButton6.Checked == true)
                {
                    pen.EndCap = LineCap.DiamondAnchor;
                }
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)//鼠标移动事件
        {
            if (mark == true)
            {
                pictureBox1.Invalidate(rec3);//刷新指定区域
                pictureBox1.Invalidate(rec4);//刷新指定区域
                pictureBox1.Invalidate(rec6);//刷新指定区域
                pictureBox1.Invalidate(rec7);//刷新指定区域
                pictureBox1.Update();//立即执行上一步
                if (type == 0)//橡皮擦
                {
                    pen0 = new Pen(Color.White, 5);//设置橡皮擦画笔
                    End = new Point(e.X, e.Y);
                    G.DrawLine(pen0, Start, End);
                    bitG.DrawLine(pen0, Start, End);
                }

                if (type == 1)//铅笔
                {
                    End = new Point(e.X, e.Y);
                    G.DrawLine(pen, Start, End);
                    bitG.DrawLine(pen, Start, End);
                }
                if (type == 2)//画直线
                {
                    G.DrawLine(pen, point.X, point.Y, e.X, e.Y);
                }
                if (type == 3) //画矩形
                { 
                    rec3 = new Rectangle(Start.X, Start.Y, e.X - Start.X, e.Y - Start.Y);
                    G.DrawRectangle(pen, rec3);
                }
                if (type == 4)//画椭圆
                {
                    rec4 = new Rectangle(Start.X, Start.Y, e.X - Start.X, e.Y - Start.Y);
                    G.DrawEllipse(pen, rec4);
                }
                if (type == 5)//画五角星
                {
                    double PI = 3.1415926535897;
                    double x0 = Convert.ToDouble(Start.X), y0 = Convert.ToDouble(Start.Y), R1 = Convert.ToDouble((e.X - Start.X)/2);//设置中心点坐标、外接圆半径
                    double R2 = R1 * 0.38196;
                    double ANG = PI / 2 - PI / 5;
                    List<Point> points = new List<Point>();
                    Point p = new Point();
                    p.X = Convert.ToInt32(x0);
                    p.Y = Convert.ToInt32(y0 + R1);
                    points.Add(p);
                    for (int i = 1; i < 10; i++)
                    {
                        if (i % 2 == 0)
                        {
                            p.X = Convert.ToInt32(x0 + R1 * Math.Cos(ANG));
                            p.Y = Convert.ToInt32(y0 + R1 * Math.Sin(ANG));
                        }
                        else
                        {
                            p.X = Convert.ToInt32(x0 + R2 * Math.Cos(ANG));
                            p.Y = Convert.ToInt32(y0 + R2 * Math.Sin(ANG));
                        }
                        points.Add(p);
                        ANG -= PI / 5;
                    }
                    G.DrawPolygon(pen, points.ToArray());
                }
                if (type == 6)//选框工具
                {
                    pen6 = new Pen(Color.Red, 2);
                    pen6.DashStyle = DashStyle.Dash;//设置选择框画笔
                    rec6 = new Rectangle(Start.X, Start.Y, e.X - Start.X, e.Y - Start.Y);
                    rec7 = new Rectangle(Start.X+2, Start.Y+2, e.X - Start.X-3, e.Y - Start.Y-3);//避免选到虚线
                    G.DrawRectangle(pen6, rec6);
                }
                if (type == 7)//画圆弧
                {
                    rec7 = new Rectangle(Start.X, Start.Y, e.X - Start.X, e.Y - Start.Y);
                    G.DrawArc(pen, 160, 50, 50, 50, 45, 180);
                }
                Start = End;//终点成为下一笔的起点
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)//鼠标松开事件
        {
            mark = false;
            if (type == 0)
            {
                bitG.DrawLine(pen0, Start, End);//最终在bitG上画，避免最小化消失
            }
            if (type == 1)
            {
                bitG.DrawLine(pen, Start, End);
            }
            if (type == 2)
            {
                bitG.DrawLine(pen, point.X, point.Y, e.X, e.Y);
            }
            if (type == 3)
            {
                bitG.DrawRectangle(pen, rec3);
            }
            if (type == 4)
            {
                bitG.DrawEllipse(pen, rec4);
            }
            if (type == 5)
            {
                double PI = 3.1415926535897;
                double x0 = Convert.ToDouble(Start.X), y0 = Convert.ToDouble(Start.Y), R1 = Convert.ToDouble((e.X - Start.X) / 2);
                double R2 = R1 * 0.38196;
                double ANG = PI / 2 - PI / 5;
                List<Point> points = new List<Point>();
                Point p = new Point();
                p.X = Convert.ToInt32(x0);
                p.Y = Convert.ToInt32(y0 + R1);
                points.Add(p);
                for (int i = 1; i < 10; i++)
                {
                    if (i % 2 == 0)
                    {
                        p.X = Convert.ToInt32(x0 + R1 * Math.Cos(ANG));
                        p.Y = Convert.ToInt32(y0 + R1 * Math.Sin(ANG));
                    }
                    else
                    {
                        p.X = Convert.ToInt32(x0 + R2 * Math.Cos(ANG));
                        p.Y = Convert.ToInt32(y0 + R2 * Math.Sin(ANG));
                    }
                    points.Add(p);
                    ANG -= PI / 5;
                }
                bitG.DrawPolygon(pen, points.ToArray());
            }
            if (type == 6)
            {
                bitG.DrawRectangle(pen6, rec6);
            }
            if (type == 7)
            {
                bitG.DrawArc(pen, 160, 50, 50, 50, 45, 180);
            }
            pictureBox1.Image = bit;//最终才生效
        }

        private void 新建ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            G.Clear(Color.White);
            bitG.Clear(Color.White);//设置白色背景
            this.Text = "绘图";
        }

        private void 打开图片ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            if (open.ShowDialog() == DialogResult.OK)
            {
                bit = new Bitmap(open.FileName);
                pictureBox1.Image = bit;
                bitG = Graphics.FromImage(bit);//bit已重置，bitG也要随之重置，否则不能再图片上绘图
            }
            filename = open.FileName;
            this.Text = filename;//在标题栏显示文件路径
        }

        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog savebit = new SaveFileDialog();
            if (savebit.ShowDialog() == DialogResult.OK)
            {
                bit.Save(savebit.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);//保存为jpg格式
            }
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 线条颜色ToolStripMenuItem_Click(object sender, EventArgs e)//画笔颜色设置
        {
            ColorDialog CD = new ColorDialog();
            if (CD.ShowDialog() == DialogResult.OK)
            {
                pen.Color = CD.Color;
            }
        }

        private void 填充颜色ToolStripMenuItem_Click(object sender, EventArgs e)//设置画刷填充颜色
        {
            ColorDialog CD = new ColorDialog();
            if (CD.ShowDialog() == DialogResult.OK)//brush是基类，没有Color属性
            {
                brush = new SolidBrush(CD.Color);
            }
        }

        private void 实线ToolStripMenuItem_Click(object sender, EventArgs e)//设置实线
        {
            pen.DashStyle = DashStyle.Solid;
        }

        private void 虚线ToolStripMenuItem_Click(object sender, EventArgs e)//设置虚线
        {
            pen.DashStyle = DashStyle.Dash;
        }

        private void 点线ToolStripMenuItem_Click(object sender, EventArgs e)//设置点线
        {
            pen.DashStyle = DashStyle.DashDot;
        }

        private void 阴影画刷ToolStripMenuItem_Click(object sender, EventArgs e)//设置阴影画刷
        {
            brush = new HatchBrush(HatchStyle.Cross, Color.Red, Color.White);
        }

        private void 图像画刷ToolStripMenuItem_Click(object sender, EventArgs e)//设置图片画刷
        {
            OpenFileDialog OFD = new OpenFileDialog();
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                Bitmap bit = new Bitmap(OFD.FileName);
                brush = new TextureBrush(bit, WrapMode.Tile);
            }
        }

        private void 橡皮擦ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            type = 0;
            pictureBox1.Cursor = Cursors.Hand;
            toolStripStatusLabel2.Text = "当前工具：橡皮擦";
        }

        private void 反色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < bit.Width; i++)
            {
                for (int j = 0; j < bit.Height; j++)
                {
                    Color color = bit.GetPixel(i, j);
                    bit.SetPixel(i, j, Color.FromArgb(255 - color.R, 255 - color.G, 255 - color.B));
                    //Color newcolor = new Color();
                    //newcolor.R = Convert.ToByte(255 - Convert.ToInt32(color.R));
                }
                pictureBox1.Image = bit;//重新处理完需把相纸放回去，每一步处理都要
            }
        }

        private void 灰度ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a;
            for (int i = 0; i < bit.Width; i++)
            {
                for (int j = 0; j < bit.Height; j++)
                {
                    Color color = bit.GetPixel(i, j);
                    a = (color.R + color.G + color.B) / 3;
                    bit.SetPixel(i, j, Color.FromArgb(a, a, a));
                }
                pictureBox1.Image = bit;//重新处理完需把相纸放回去，每一步处理都要
            }
        }

        private void 浮雕ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < bit.Width - 1; i++)
            {
                for (int j = 0; j < bit.Height - 1; j++)
                {
                    int r = 0, g = 0, b = 0;
                    Color color1 = bit.GetPixel(i, j);
                    Color color2 = bit.GetPixel(i + 1, j + 1);
                    r = Math.Abs(color1.R - color2.R + 128);
                    g = Math.Abs(color1.G - color2.G + 128);
                    b = Math.Abs(color1.B - color2.B + 128);
                    if (r > 255)
                        r = 255;
                    if (r < 0)
                        r = 0;
                    if (g > 255)
                        g = 255;
                    if (g < 0)
                        g = 0;
                    if (b > 255)
                        b = 255;
                    if (b < 0)
                        b = 0;
                    bit.SetPixel(i, j, Color.FromArgb(r, g, b));
                }
                pictureBox1.Image = bit;//重新处理完需把相纸放回去，每一步处理都要
            }
        }

        private void button16_Click(object sender, EventArgs e)//填充按钮
        {
            if (type == 3)
            {
                bitG.FillRectangle(brush, rec3);
                pictureBox1.Image = bit;
            }
            if (type == 4)
            {
                bitG.FillEllipse(brush, rec4);
                pictureBox1.Image = bit;
            }
        }

        private void button8_Click(object sender, EventArgs e)//选择铅笔
        {
            type = 1;
            Cursor PenCursor = new Cursor(Cursor.Current.Handle);
            IntPtr colorCursorHandle = LoadCursorFromFile(AppDomain.CurrentDomain.BaseDirectory + "pen.cur");//鼠标图标路径
            PenCursor.GetType().InvokeMember("handle", BindingFlags.Public |
            BindingFlags.NonPublic | BindingFlags.Instance |
            BindingFlags.SetField, null, PenCursor,
            new object[] { colorCursorHandle });
            pictureBox1.Cursor = PenCursor;
            toolStripStatusLabel2.Text = "当前工具：铅笔";
        }

        private void button9_Click(object sender, EventArgs e)//选择画直线
        {
            type = 2;
            pictureBox1.Cursor = Cursors.Cross;
            toolStripStatusLabel2.Text = "当前绘制：直线";
        }

        private void button10_Click(object sender, EventArgs e)//选择画矩形
        {
            type = 3;
            pictureBox1.Cursor = Cursors.Cross;
            toolStripStatusLabel2.Text = "当前绘制：矩形";
        }

        private void button11_Click(object sender, EventArgs e)//选择画椭圆
        {
            type = 4;
            pictureBox1.Cursor = Cursors.Cross;
            toolStripStatusLabel2.Text = "当前绘制：椭圆";
        }

        private void button12_Click(object sender, EventArgs e)//选择画五角星
        {
            type = 5;
            pictureBox1.Cursor = Cursors.Cross;
            toolStripStatusLabel2.Text = "当前绘制：五角星";
        }

        private void button15_Click(object sender, EventArgs e)//选框工具
        {
            type = 6;
            pictureBox1.Cursor = Cursors.Cross;
            toolStripStatusLabel2.Text = "当前工具：选择";
        }

        private void button17_Click(object sender, EventArgs e)//选择画圆弧
        {
            type = 7;
            pictureBox1.Cursor = Cursors.Cross;
            toolStripStatusLabel2.Text = "当前绘制：圆弧";
        }

        private void numericUpDownFontSize_ValueChanged(object sender, EventArgs e)//设置画笔粗细
        {
            pen = new Pen(pen.Color, (float)numericUpDownFontSize.Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pen = new Pen(Color.White, pen.Width);//设置画笔为白色
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pen = new Pen(Color.Black, pen.Width);//设置画笔为黑色
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pen = new Pen(Color.Red, pen.Width);//设置画笔为红色
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pen = new Pen(Color.Green, pen.Width);//设置画笔为绿色
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pen = new Pen(Color.Blue, pen.Width);//设置画笔为蓝色
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pen = new Pen(Color.Yellow, pen.Width);//设置画笔为黄色
        }

        private void button7_Click(object sender, EventArgs e)//设置其他画笔颜色
        {
            ColorDialog CD = new ColorDialog();
            if (CD.ShowDialog() == DialogResult.OK)
            {
                pen.Color = CD.Color;
            }
        }

        private void splitButton1_Click(object sender, EventArgs e)//旋转按钮
        {
            Bitmap bits = new Bitmap(pictureBox1.Image);
            bit.RotateFlip(RotateFlipType.Rotate90FlipNone);
            pictureBox1.Image = bit;

        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)//向右旋转90度
        {
            Bitmap bits = new Bitmap(pictureBox1.Image);
            bit.RotateFlip(RotateFlipType.Rotate90FlipNone);
            pictureBox1.Image = bit;
        }

        private void 向左旋转90度ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap bits = new Bitmap(pictureBox1.Image);
            bit.RotateFlip(RotateFlipType.Rotate270FlipNone);
            pictureBox1.Image = bit;
        }

        private void 旋转180度ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap bits = new Bitmap(pictureBox1.Image);
            bit.RotateFlip(RotateFlipType.RotateNoneFlipXY);
            pictureBox1.Image = bit;
        }

        private void 垂直翻转ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap bits = new Bitmap(pictureBox1.Image);
            bit.RotateFlip(RotateFlipType.RotateNoneFlipY);
            pictureBox1.Image = bit;
        }

        private void 水平翻转ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bitmap bits = new Bitmap(pictureBox1.Image);
            bit.RotateFlip(RotateFlipType.RotateNoneFlipX);
            pictureBox1.Image = bit;
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)//打开关于界面
        {
            Form2 FindReplaceDialog = new Form2(this);
            FindReplaceDialog.ShowDialog();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = DateTime.Now.ToLongTimeString();//打开就能显示时间，不用等一秒
        }
    }
}
